import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BoardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
