import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-bootstrap',
  templateUrl: './basic-bootstrap.component.html',
  styleUrls: ['./basic-bootstrap.component.scss']
})
export class BasicBootstrapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
