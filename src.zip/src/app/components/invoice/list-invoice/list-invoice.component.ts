import {Component, OnInit, ViewEncapsulation} from '@angular/core';

@Component({
  selector: 'app-list-invoice',
  templateUrl: './list-invoice.component.html',
  styleUrls: ['./list-invoice.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ListInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
