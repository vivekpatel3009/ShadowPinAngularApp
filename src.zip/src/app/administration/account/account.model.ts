import { IBaseEntity } from "../../model/base.model";

export interface IAccountInfo extends IBaseEntity
{

    

}