import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListChartComponent } from './list-chart.component';

describe('ListChartComponent', () => {
  let component: ListChartComponent;
  let fixture: ComponentFixture<ListChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
