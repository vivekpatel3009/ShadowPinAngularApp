import { Injectable } from '@angular/core';
import { MenuItems,MainMenuItems } from '../shared/menu-items/menu-items';
import { AuthRights } from './auth-rights';

@Injectable()
export class AuthService
{

    accessiblemenuItems : MainMenuItems[];
    currentmenu:any;

    constructor(public menuItems:MenuItems) 
    {
        this.accessiblemenuItems = menuItems.getAll();
    }

    checkRights(state:any,mode:any)
    {
        this.currentmenu = undefined;

        for(let item of this.accessiblemenuItems)
        {   
            if(item.state == state)
            {
                this.currentmenu=item;
                break;
            }

            for(let childitem of item.children)
            {   
                if(childitem.state == state)
                {
                    this.currentmenu = childitem;
                    break;
                }
            }

            if(this.currentmenu != undefined)
            {
                break;
            }

        }

        if(this.currentmenu != undefined)
        {
             if(mode == AuthRights.View)
            {
                if(this.currentmenu.isallowedview == true)
                {
                    return true; 
                }
            }

            if(mode == AuthRights.Create)
            {
                if(this.currentmenu.isallowedcreate == true)
                {
                    return true; 
                }
            }
            if(mode == AuthRights.Edit)
            {
                if(this.currentmenu.isallowededit == true)
                {
                    return true; 
                }
            }

            if(mode == AuthRights.Delete)
            {
                if(this.currentmenu.isalloweddelete == true)
                {
                    return true; 
                }
            }
        }

        return false;
        
    }
    
}



