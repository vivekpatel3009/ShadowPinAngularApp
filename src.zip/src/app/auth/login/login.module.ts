import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {LoginRoutingModule1} from './login-routing.module';
import {SharedModule} from '../../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    LoginRoutingModule1,
    SharedModule
  ],
  declarations: []
})
export class LoginModule1 { }
