import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ForgotService } from './forgot.service';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class ForgotComponent implements OnInit 
{
  public forgotpasswordform: FormGroup;
  emailid:string='';
  public jsonresponse:any;
  submitted:any;
  constructor(private loginFormBuilder: FormBuilder,private _ForgotService:ForgotService ) 
  { 
      this.emailid='';
  }

  onSubmit()
  {
        // this._ForgotService.forgotPassword(this.emailid).subscribe(response=>
        // {
        //     this.jsonresponse=response;

        //     if(this.jsonresponse.Status == true)
        //     {
        //         alert(this.jsonresponse.Messsage);
        //     }
                
        // },
        // error=>
        // {
        //     console.log(error);
        // });
    
  }
    

  ngOnInit() 
  {
      this.forgotpasswordform = this.loginFormBuilder.group({
        email: ['', [Validators.required, Validators.email]],
      })
  }


}
