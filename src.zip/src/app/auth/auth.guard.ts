import { Injectable } from '@angular/core';
import { CanActivate,CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { MainMenuItems } from '../shared/menu-items/menu-items';
import { PopupMessageService } from '../service/popupMessageService';

@Injectable()
export class AuthGuard implements CanActivate,CanActivateChild
{
    constructor(private router: Router,private authService :AuthService,private popupMessageService:PopupMessageService) {}

    accessiblemenuItems : MainMenuItems[];

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) 
    {
        if (sessionStorage.getItem('isLoggedin')) 
        {
            return true;
        }

        this.router.navigate(['/login']);

        return false;
    }

    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean 
    {
        if(route.data.state != undefined && route.data.mode != undefined)
        {
            if(route.data.mode == 'main')
            {
                return true;
            }
            else
            {
                let IsAllowed;

                IsAllowed = this.authService.checkRights(route.data.state,route.data.mode);

                if(!IsAllowed)
                {
                    this.popupMessageService.openBasicSwal("Warning","you don't have rights for this menu");

                    this.router.navigate(['/dashboard']);
                }

                return IsAllowed;
            }
        }
        return false ;
    }
    

}

