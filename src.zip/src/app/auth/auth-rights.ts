export enum AuthRights 
{
    View= 'view',
    Create='create',
    Edit='edit',
    Delete='delete'
}